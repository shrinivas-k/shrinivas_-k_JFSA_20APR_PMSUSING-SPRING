package com.te.productmanagement.DAO;

import com.te.productmanagement.beans.productbeans;

public interface productdao {

//	public productbeans authenticate(int id, String pwd);

	public productbeans  getproductData(int pid);

	public boolean deleteproduct(int pid);

	public boolean addproduct( productbeans  pb);

	public boolean updateRecord( productbeans  pb);

//	public productbeans authenticate(int id, String pwd)
	

	productbeans authenticate(String name, String pwd);

	public productbeans authenticate(int id, String pwd);
}
