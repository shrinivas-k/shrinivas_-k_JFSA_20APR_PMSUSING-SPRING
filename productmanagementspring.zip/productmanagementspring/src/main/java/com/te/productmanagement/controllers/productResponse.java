package com.te.productmanagement.controllers;

import com.te.productmanagement.beans.productbeans;

public class productResponse {

	public void setStatusCode(int i) {
		// TODO Auto-generated method stub
		
	}

	public void setMsg(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setDescription(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setproductbeans(productbeans pb) {
		// TODO Auto-generated method stub
		
	}

}
