package com.te.productmanagement.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.productmanagement.beans.productbeans;

public class productdaoilmpl implements productdao {

	@Override
	public productbeans authenticate(String name, String pwd) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
		EntityManager manager = factory.createEntityManager();
		Object pid;
		productbeans pb = manager.find(productbeans.class, pid);

		if( pb != null) {
			if (pb.getPassword().equals(pwd)) {
				return pb;
			} else {
				throw new Exception("Password is wrong");
			}
		}else {
			throw new Exception("Invalid ID");
		}
		return null;
	}
}
	@Override
	public productbeans getproductData(int pid) {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
			EntityManager manager = factory.createEntityManager();
		productbeans pb = manager.find(productbeans.class, pid);
			manager.close();
			factory.close();
			return pb;
		
	}

	@Override
	public boolean deleteproduct(int pid) {
		boolean isDeleted = false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			productbeans pb = manager.find(productbeans.class, pid);
			manager.remove(pb);
			transaction.commit();
			isDeleted = true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}

		return isDeleted;
	}

	@Override
	public boolean addproduct(productbeans pb) {
		boolean isInserted = false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		try {
			transaction.begin();
			manager.persist(pb);
			transaction.commit();
			isInserted = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return isInserted;
	}
	@Override
	public boolean updateRecord(productbeans pb) {
		boolean isUpdated = false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
		productbeans actualInfo = manager.find(productbeans.class, pb.getPid());

			if (pb.getPname() != null && pb.getPname() != "") {
				actualInfo.setPname(pb.getPname());
			}

			if (pb.getMgdate() != null) {
				actualInfo.setMgdate(pb.getMgdate());
			}

			if (pb.getPassword() != null &&pb.getPassword() != "") {
				actualInfo.setPassword(pb.getPassword());
			}

			transaction.commit();
			isUpdated = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return isUpdated;
	}

	@Override
	public productbeans authenticate(int id, String pwd) {
		// TODO Auto-generated method stub
		return null;
	}



}
