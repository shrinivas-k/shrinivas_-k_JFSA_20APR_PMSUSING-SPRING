package com.te.productmanagement.services;

import java.util.List;

import com.te.productmanagement.beans.productbeans;

public interface productservic {
	public productbeans authenticate(int id, String pwd);

	public boolean deleteEmpData(int id);
	
	public boolean addproduct( productbeans employeeInfoBean);
	
	public boolean updateRecord( productbeans employeeInfoBean);
	

	productbeans getproductData(int id);
}
